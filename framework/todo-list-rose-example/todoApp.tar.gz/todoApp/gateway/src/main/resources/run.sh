#!/bin/sh

echo "\n"
echo "\t==========================================="
echo "\t=                                         ="
echo "\t= @}-'-,-- RoSe Web Distribution --,-'-{@ ="
echo "\t=                                         ="
echo "\t==========================================="
echo "\n"

java -jar core/org.apache.felix.main-4.0.3.jar $@

