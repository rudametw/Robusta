cp ../../robusta-java-agent/target/robusta-java-agent-1.0.0-SNAPSHOT.jar robusta/
